import React, { useState } from 'react';

const Product = ({data}) => {
    const [item, setItem]=useState(data);
    console.log(item)
    // setItem(data);
  return (
    <div>
      <div className='container'>
        <div className='row'>
        {
        item.map((products)=>{
            const {id, img, heading, price} = products;
            return(
                    <div className='col-6 col-md-4, col-sm-3 py-3 'key={id}>
                        <img className='img-fluid' src={img} alt=""/>
                        <h2>{heading}</h2>
                        <p>{price}</p>
                        </div>         
            )
        })
      }
        </div>
      </div>
    </div>
  )
}

export default Product;
