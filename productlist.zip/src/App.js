import React from 'react';
import Product from './Component/Product';
import {list} from './data';

function App() {
  return (
    <Product data ={list}/>
  );
}

export default App;
