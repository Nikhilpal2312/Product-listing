export const list=[
    {
        id:1,
    img:'https://images.bewakoof.com/t640/men-s-blue-marvel-moon-knight-graphic-printed-t-shirt-483814-1655749326-1.jpg',
    heading:"moon knight",
    price:'Rs. 499/',
    },
    {
        id:2,
    img:'https://images.bewakoof.com/t640/men-s-black-killmonger-graphic-printed-t-shirt-509349-1655797675-1.jpg',
    heading:"Black-killmonger",
    price:'Rs. 599/',
    },
    {
        id:3,
    img:'https://images.bewakoof.com/t640/men-s-black-i-need-some-space-teddy-graphic-printed-t-shirt-496045-1655749010-1.jpg',
    heading:"Black space teddy",
    price:'Rs. 499/',
    },
    {
        id:4,
    img:'https://images.bewakoof.com/t640/men-s-blue-marvel-moon-knight-graphic-printed-t-shirt-483814-1655749326-1.jpg',
    heading:"Moon Knight",
    price:'Rs. 499/',
    },
    {
        id:5,
    img:'https://images.bewakoof.com/t640/men-s-black-galaxy-cricket-graphic-printed-t-shirt-489754-1655749349-1.jpg',
    heading:"Black Galaxy",
    price:'Rs. 499/',
    },
    {
        id:6,
    img:'https://images.bewakoof.com/t640/the-king-half-sleeve-t-shirt-543363-1663760009-1.jpg',
    heading:"King Half ",
    price:'Rs. 649/',
    },
    {
        id:7,
    img:'https://images.bewakoof.com/t640/men-s-red-striped-oversized-t-shirt-425013-1667553371-1.jpg',
    heading:"Striped Oversize",
    price:'Rs. 599/',
    },
    {
        id:8,
    img:'https://images.bewakoof.com/t640/men-s-black-witcher-of-rivia-graphic-printed-oversized-t-shirt-519192-1667519467-1.jpg',
    heading:"Black Witcher",
    price:'Rs. 499/',
    },
    {
        id:9,
    img:'https://images.bewakoof.com/t640/men-s-red-the-batman-oversized-fit-t-shirt-480316-1667507467-1.jpg',
    heading:"Men Oversized",
    price:'Rs. 499/',
    },
    {
        id:10,
    img:'https://images.bewakoof.com/t640/unisex-black-i-don-think-so-printed-t-shirt-516699-1667912331-1.jpg',
    heading:"Unisex Black",
    price:'Rs. 499/',
    },
    {
        id:11,
        img:"https://images.bewakoof.com/t640/men-s-blue-peace-not-war-graphic-printed-oversized-t-shirt-479634-1667556897-1.jpg",
        heading:'Blue Peace War',
        price:"Rs. 399/"
    },
    {
        id:12,
        img:"https://images.bewakoof.com/t640/pageant-blue-candy-block-half-sleeve-t-shirt-333629-1656184294-6.jpg",
        heading:'Pageant Blue Candy',
        price:"Rs. 539/"
    },
    

]